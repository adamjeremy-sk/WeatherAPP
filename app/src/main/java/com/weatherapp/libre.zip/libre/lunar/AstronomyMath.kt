package com.weatherapp.libre.lunar

import kotlin.math.*

object AstronomyMath {

    fun normalizeDegrees(angle: Double): Double {
        var a = angle % 360.0
        if (a < 0.0) a += 360.0
        return a
    }

    fun degToRad(deg: Double): Double = Math.toRadians(deg)
    fun radToDeg(rad: Double): Double = Math.toDegrees(rad)

    /**
     * Greenwich Mean Sidereal Time (GMST) in degrees for a given JD in UTC.
     * Meeus Ch. 12 Eq. 12.4
     *
     * T is computed in UT centuries from JD in UTC, approximating UT1 (|UT1 - UTC| < 0.9 s),
     * yielding a GMST error below ~0.004 degrees; DUT1 correction deliberately not
     * implemented to preserve offline operation.
     *
     * @param jdUtc Julian Date in UTC.
     * @return Greenwich Mean Sidereal Time in degrees in [0, 360).
     */
    fun gmstDegrees(jdUtc: Double): Double {
        val d = jdUtc - 2451545.0
        val T = d / 36525.0
        val gmstDeg = 280.46061837 + 360.98564736629 * d + 0.000387933 * T * T - (T * T * T / 38710000.0)
        return normalizeDegrees(gmstDeg)
    }

    data class ObliquityAndNutation(
        val meanObliquityDeg: Double,
        val trueObliquityDeg: Double,
        val nutationInLongitudeDeg: Double,
        val nutationInObliquityDeg: Double
    )

    /**
     * Nutation and obliquity of the ecliptic.
     * Meeus Ch. 22
     *
     * T is computed in TT centuries via [AstroTime.julianCenturiesTT] per Meeus Ch. 22.
     *
     * @param jdeTT Julian Ephemeris Day in TT.
     * @return [ObliquityAndNutation] instance containing obliquity and nutation components.
     */
    fun nutationAndObliquity(jdeTT: Double): ObliquityAndNutation {
        val T = AstroTime.julianCenturiesTT(jdeTT)

        val eps0Seconds = 84381.448 - 46.8150 * T - 0.00059 * T * T + 0.001813 * T * T * T
        val eps0Deg = eps0Seconds / 3600.0

        val omegaRad = degToRad(normalizeDegrees(125.04452 - 1934.136261 * T + 0.0020708 * T * T + T * T * T / 450000.0))
        val LRad     = degToRad(normalizeDegrees(280.4665 + 36000.7698 * T))
        val LdashRad = degToRad(normalizeDegrees(218.3165 + 481267.8813 * T))

        val deltaPsiSec = -17.20 * sin(omegaRad) - 1.32 * sin(2.0 * LRad) - 0.23 * sin(2.0 * LdashRad) + 0.21 * sin(2.0 * omegaRad)
        val deltaEpsSec = 9.20 * cos(omegaRad) + 0.57 * cos(2.0 * LRad) + 0.10 * cos(2.0 * LdashRad) - 0.09 * cos(2.0 * omegaRad)

        val deltaPsiDeg = deltaPsiSec / 3600.0
        val deltaEpsDeg = deltaEpsSec / 3600.0
        val trueEpsDeg = eps0Deg + deltaEpsDeg

        return ObliquityAndNutation(
            meanObliquityDeg = eps0Deg,
            trueObliquityDeg = trueEpsDeg,
            nutationInLongitudeDeg = deltaPsiDeg,
            nutationInObliquityDeg = deltaEpsDeg
        )
    }

    /**
     * Greenwich Apparent Sidereal Time (GAST) in degrees.
     */
    fun gastDegrees(jdUtc: Double, jdeTT: Double): Double {
        val gmst = gmstDegrees(jdUtc)
        val nut = nutationAndObliquity(jdeTT)
        val gast = gmst + nut.nutationInLongitudeDeg * cos(degToRad(nut.trueObliquityDeg))
        return normalizeDegrees(gast)
    }

    data class Equatorial(val raDeg: Double, val decDeg: Double)

    /**
     * Converts Ecliptic (lambda, beta) to Equatorial (RA, Dec) coordinates.
     * Meeus Ch. 13 Eq 13.3, 13.4
     */
    fun eclipticToEquatorial(lambdaDeg: Double, betaDeg: Double, epsDeg: Double): Equatorial {
        val lamRad = degToRad(lambdaDeg)
        val betRad = degToRad(betaDeg)
        val epsRad = degToRad(epsDeg)

        val sinDec = sin(betRad) * cos(epsRad) + cos(betRad) * sin(epsRad) * sin(lamRad)
        val decRad = asin(sinDec.coerceIn(-1.0, 1.0))

        val y = sin(lamRad) * cos(epsRad) - tan(betRad) * sin(epsRad)
        val x = cos(lamRad)
        val raRad = atan2(y, x)

        return Equatorial(
            raDeg = normalizeDegrees(radToDeg(raRad)),
            decDeg = radToDeg(decRad)
        )
    }
}
